var classStack =
[
    [ "clear", "classStack.html#a76a89552d8b31e5401582328db745e42", null ],
    [ "isEmpty", "classStack.html#a27ce2162992eb922e55dd554e8281091", null ],
    [ "pull", "classStack.html#a7390012b3ec2cdc69658a11640a1780c", null ],
    [ "push", "classStack.html#ad6c1a920ef922fb7d7cac36d7fb21aeb", null ],
    [ "size", "classStack.html#a4d17334ae17c9b50bb9e9d53057bff1e", null ],
    [ "first", "classStack.html#ab0ce11b7409d4ecada756d98097b066e", null ]
];