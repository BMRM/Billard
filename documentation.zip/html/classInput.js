var classInput =
[
    [ "queuing", "classInput.html#a1662ab19bc4806b69e0c756113991969", null ],
    [ "update", "classInput.html#a808c0253653fbe3f328899f4653bb88a", null ],
    [ "buffer", "classInput.html#ac0f0975268f1ba6ac7954971aed33584", null ],
    [ "kb", "classInput.html#aad7e47ac6c1753bbadc8efa8770b0213", null ],
    [ "out", "classInput.html#ad2573405ffbe747452f6a839c8b43513", null ],
    [ "queue", "classInput.html#af4d60826a5e18c8467c403ba991073f3", null ]
];