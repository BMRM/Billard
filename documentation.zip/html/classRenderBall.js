var classRenderBall =
[
    [ "make", "classRenderBall.html#ab72b93e4fbd67a7f99475ab7318fb68d", null ],
    [ "render", "classRenderBall.html#a4ca9df92d3431902cca99bb96bf1ad95", null ],
    [ "update", "classRenderBall.html#a636f60daab9356f4e896c330f9a25334", null ],
    [ "c", "classRenderBall.html#af86d41a2c4370b483cec184cd1460fe9", null ],
    [ "r", "classRenderBall.html#ace72c2ad857526f0d2890ceef797046f", null ],
    [ "x", "classRenderBall.html#a67cadf50e10381f9c4be08aee0d92230", null ],
    [ "y", "classRenderBall.html#a813bcb42e92690f17315b53e51bcffa8", null ]
];