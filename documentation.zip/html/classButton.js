var classButton =
[
    [ "make", "classButton.html#a46f745a94cee7e4219168b3bb0d075a9", null ],
    [ "render", "classButton.html#a6a999ae395798dbf4cce463ea1886681", null ],
    [ "update", "classButton.html#af1947c7a7028cd4f9e50b2d2e00a63f6", null ],
    [ "b", "classButton.html#a160225f05ff4e76104cc09e386c4046e", null ],
    [ "border", "classButton.html#a96d3b499e2f5b9f779421805134fbe2d", null ],
    [ "design", "classButton.html#ae5f882d97e4c6b10dbb254b9b35b4fd6", null ],
    [ "size", "classButton.html#acb6d63ab9b494633992a97b9eec43093", null ],
    [ "state", "classButton.html#a2a763c704c5286f96c5cd32edcb6ec5b", null ],
    [ "title", "classButton.html#acd1ad1b95d8cb953e55afefedd8c2ad5", null ]
];