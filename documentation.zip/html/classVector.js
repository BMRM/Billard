var classVector =
[
    [ "atan", "classVector.html#a353d3a1eb8ac585adf81cbb27d335a87", null ],
    [ "dump", "classVector.html#a60ee49eedd120a07f2ab475419eca3aa", null ],
    [ "formeCart", "classVector.html#a150ef7d4ba42098dacb1ad92e61da05b", null ],
    [ "formePol", "classVector.html#aa956a76aacb637bc1717dcb30e7b17c5", null ],
    [ "module", "classVector.html#af4e7542d4b3c6ee46aa8453efbd33d69", null ],
    [ "newBase", "classVector.html#ad938a7bda0815e5bf13cb6ef814863eb", null ],
    [ "reverseBase", "classVector.html#a60f589db739703e367cb70840ca2ad94", null ],
    [ "a", "classVector.html#a77e4cf4e8a8656e5dfeaaabc4694adc4", null ],
    [ "m", "classVector.html#a17384e7d2ce6a16d50eb94cc367235bd", null ],
    [ "x", "classVector.html#adecf93c0c16dae242c46ac32f8f1a966", null ],
    [ "y", "classVector.html#a5a4c7a85ea917c0e647108a9b32ef319", null ]
];