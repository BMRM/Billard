var files =
[
    [ "Ball.java", "Ball_8java.html", [
      [ "Ball", "classBall.html", "classBall" ]
    ] ],
    [ "Billard.java", "Billard_8java.html", [
      [ "Billard", "classBillard.html", "classBillard" ]
    ] ],
    [ "Board.java", "Board_8java.html", [
      [ "Indicator", "classIndicator.html", "classIndicator" ],
      [ "Graph", "classGraph.html", "classGraph" ],
      [ "Board", "classBoard.html", "classBoard" ]
    ] ],
    [ "Box.java", "Box_8java.html", [
      [ "Box", "classBox.html", "classBox" ]
    ] ],
    [ "Button.java", "Button_8java.html", [
      [ "Button", "classButton.html", "classButton" ]
    ] ],
    [ "Color.java", "Color_8java.html", [
      [ "Color", "classColor.html", "classColor" ]
    ] ],
    [ "Input.java", "Input_8java.html", [
      [ "Input", "classInput.html", "classInput" ]
    ] ],
    [ "Menu.java", "Menu_8java.html", [
      [ "Menu", "classMenu.html", "classMenu" ]
    ] ],
    [ "Rect.java", "Rect_8java.html", [
      [ "Rect", "classRect.html", "classRect" ]
    ] ],
    [ "RenderBall.java", "RenderBall_8java.html", [
      [ "RenderBall", "classRenderBall.html", "classRenderBall" ]
    ] ],
    [ "Stack.java", "Stack_8java.html", [
      [ "Event", "classEvent.html", "classEvent" ],
      [ "Item", "classItem.html", "classItem" ],
      [ "Stack", "classStack.html", "classStack" ]
    ] ],
    [ "Vector.java", "Vector_8java.html", [
      [ "Vector", "classVector.html", "classVector" ]
    ] ],
    [ "Window.java", "Window_8java.html", [
      [ "Window", "classWindow.html", "classWindow" ]
    ] ]
];