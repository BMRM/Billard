var annotated =
[
    [ "Ball", "classBall.html", "classBall" ],
    [ "Billard", "classBillard.html", "classBillard" ],
    [ "Board", "classBoard.html", "classBoard" ],
    [ "Box", "classBox.html", "classBox" ],
    [ "Button", "classButton.html", "classButton" ],
    [ "Color", "classColor.html", "classColor" ],
    [ "Event", "classEvent.html", "classEvent" ],
    [ "Graph", "classGraph.html", "classGraph" ],
    [ "Indicator", "classIndicator.html", "classIndicator" ],
    [ "Input", "classInput.html", "classInput" ],
    [ "Item", "classItem.html", "classItem" ],
    [ "Menu", "classMenu.html", "classMenu" ],
    [ "Rect", "classRect.html", "classRect" ],
    [ "RenderBall", "classRenderBall.html", "classRenderBall" ],
    [ "Stack", "classStack.html", "classStack" ],
    [ "Vector", "classVector.html", "classVector" ],
    [ "Window", "classWindow.html", "classWindow" ]
];