var classBoard =
[
    [ "make", "classBoard.html#aaf94323dbd1fc23d5c228d333137727f", null ],
    [ "render", "classBoard.html#a66eb49e91858732fba7e685119e03032", null ],
    [ "update", "classBoard.html#ab476362a025698e26bb9cea1f58a458a", null ],
    [ "graphs", "classBoard.html#afcba1fe2fbffd0e668cb9c37558ed3e1", null ],
    [ "indicators", "classBoard.html#a02f3195bf0b46533b22972d5bed7a515", null ],
    [ "nbGraphs", "classBoard.html#ac8b46c8ffe3128ab66084ca58c0a7e22", null ],
    [ "nbIndicators", "classBoard.html#abc1503c45331ad60d3ef72926c53e2e5", null ],
    [ "size", "classBoard.html#a1ea5d96493533df830c9938f2c7c9bb8", null ]
];