var classWindow =
[
    [ "make", "classWindow.html#a30a643b199e64309c9198bf0a666ed34", null ],
    [ "render", "classWindow.html#a1f3f8c843abb71564f37f5264f123c4d", null ],
    [ "renderBox", "classWindow.html#a9f4bc959ab70e56ea97043df2a6411a1", null ],
    [ "renderInput", "classWindow.html#a72e00051adf9f1d17204296a0b9463aa", null ],
    [ "renderQueue", "classWindow.html#ab7bd36feaa88dc0def0258a3fc204cce", null ],
    [ "update", "classWindow.html#a57472f1efc429f6b5143401b40aefb86", null ],
    [ "board", "classWindow.html#abf55250bfa968a16f08e5fa6dafa3d94", null ],
    [ "fps", "classWindow.html#af467386e593cc9cff51ae17a5fdc6967", null ],
    [ "height", "classWindow.html#ae2244876e62d9ad1e6145f64feb2f871", null ],
    [ "menu", "classWindow.html#a8f68e38da88c18def4f684dff7d7ce39", null ],
    [ "nbBalls", "classWindow.html#a2ec9cf644522a5c6fb36b698b82d5aa6", null ],
    [ "renderBalls", "classWindow.html#a6e71186913038e7829345136d7a7cd52", null ],
    [ "scale", "classWindow.html#a8a890c19633e97b9d2019b09b5e50030", null ],
    [ "sizeBoard", "classWindow.html#a0ce018fcea76bd4244200c819099983a", null ],
    [ "sizeMenu", "classWindow.html#a646f3cc6f30e8f6d24c13c4d41239bfd", null ],
    [ "width", "classWindow.html#ae45dd27bbd91b0ef7d8ba96d27b62b56", null ]
];