var searchData=
[
  ['graph',['Graph',['../classGraph.html',1,'Graph'],['../classGraph.html#afe5379f235fd11085c3dba2946c47df9',1,'Graph.graph()']]],
  ['graphs',['graphs',['../classBoard.html#afcba1fe2fbffd0e668cb9c37558ed3e1',1,'Board']]]
];
