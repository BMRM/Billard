var searchData=
[
  ['unite',['unite',['../classIndicator.html#a084e9b7735162df1ee35d89d0efe10c6',1,'Indicator']]]
];
