var searchData=
[
  ['set',['set',['../classColor.html#a07a6c69ebd64a781d465e88807d7677c',1,'Color']]],
  ['size',['size',['../classStack.html#a4d17334ae17c9b50bb9e9d53057bff1e',1,'Stack']]]
];
