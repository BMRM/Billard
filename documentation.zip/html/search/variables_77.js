var searchData=
[
  ['w',['w',['../classRect.html#ae105921ac01f202298490b24aff35e84',1,'Rect']]],
  ['width',['width',['../classBox.html#ab9540b422990d205b1fb32a2f8fd62b5',1,'Box.width()'],['../classWindow.html#ae45dd27bbd91b0ef7d8ba96d27b62b56',1,'Window.width()']]]
];
