var searchData=
[
  ['id',['id',['../classBall.html#a6b413c33f7783b64705c908e65202fa4',1,'Ball']]],
  ['indicator',['indicator',['../classGraph.html#a8c3f8dc70f809f2a156784882a9cbbe7',1,'Graph']]],
  ['indicators',['indicators',['../classBoard.html#a02f3195bf0b46533b22972d5bed7a515',1,'Board']]]
];
