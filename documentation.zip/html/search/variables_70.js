var searchData=
[
  ['p',['p',['../classBall.html#a4243b74027f89190a94710bc906495b8',1,'Ball.p()'],['../classBox.html#afdfc6400faf9ed9fe3897404ffcbb941',1,'Box.p()']]],
  ['precision',['precision',['../classIndicator.html#a30c4c774867da3f4c08e10ecc1fb7dab',1,'Indicator']]]
];
