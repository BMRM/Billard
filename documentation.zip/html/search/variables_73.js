var searchData=
[
  ['s',['s',['../classBox.html#a11a20c7f11aeef5057001d5353d73139',1,'Box']]],
  ['scale',['scale',['../classGraph.html#ab71ae9620c78cf9dfc7936af40c696a4',1,'Graph.scale()'],['../classWindow.html#a8a890c19633e97b9d2019b09b5e50030',1,'Window.scale()']]],
  ['size',['size',['../classIndicator.html#a3e29377a9a3102083706786e274be6b7',1,'Indicator.size()'],['../classGraph.html#a7338f21d2ed92b070150483fda78613f',1,'Graph.size()'],['../classBoard.html#a1ea5d96493533df830c9938f2c7c9bb8',1,'Board.size()'],['../classButton.html#acb6d63ab9b494633992a97b9eec43093',1,'Button.size()'],['../classMenu.html#a444faeb5569dc5f8fe7f5a9751138a86',1,'Menu.size()']]],
  ['sizeboard',['sizeBoard',['../classWindow.html#a0ce018fcea76bd4244200c819099983a',1,'Window']]],
  ['sizemenu',['sizeMenu',['../classWindow.html#a646f3cc6f30e8f6d24c13c4d41239bfd',1,'Window']]],
  ['state',['state',['../classButton.html#a2a763c704c5286f96c5cd32edcb6ec5b',1,'Button']]]
];
