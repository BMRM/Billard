var searchData=
[
  ['newbase',['newBase',['../classVector.html#ad938a7bda0815e5bf13cb6ef814863eb',1,'Vector']]]
];
