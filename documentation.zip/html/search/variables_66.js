var searchData=
[
  ['first',['first',['../classStack.html#ab0ce11b7409d4ecada756d98097b066e',1,'Stack']]],
  ['fps',['fps',['../classWindow.html#af467386e593cc9cff51ae17a5fdc6967',1,'Window']]],
  ['friction',['friction',['../classBox.html#a02eb3b73755bff7f8f6094f1dada7d0a',1,'Box']]]
];
