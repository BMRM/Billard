var searchData=
[
  ['atan',['atan',['../classVector.html#a353d3a1eb8ac585adf81cbb27d335a87',1,'Vector']]]
];
