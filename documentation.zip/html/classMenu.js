var classMenu =
[
    [ "make", "classMenu.html#a4611bb29c182fee37e01f45eab57322e", null ],
    [ "render", "classMenu.html#a792825c442ef751653236e740c087acc", null ],
    [ "update", "classMenu.html#aa432ebfc8edbd26e4548351aae1f2df2", null ],
    [ "buttons", "classMenu.html#a38568f4260f026daef9fbd0529883b9b", null ],
    [ "nbButtons", "classMenu.html#afebec42df2aceb8f60808170a6fed4f8", null ],
    [ "size", "classMenu.html#a444faeb5569dc5f8fe7f5a9751138a86", null ],
    [ "title", "classMenu.html#afa34e0ebefc257ff969e284021b5bf4f", null ]
];