var classEvent =
[
    [ "b1", "classEvent.html#abced9fa832920c13247f78ab247007e9", null ],
    [ "b2", "classEvent.html#ae093f3d03eaa5bdef247c77bd8854abf", null ],
    [ "type", "classEvent.html#a9d196130a46c3be07f90de6cb1f75c17", null ]
];