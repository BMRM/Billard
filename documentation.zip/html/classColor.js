var classColor =
[
    [ "make", "classColor.html#a6fa54a633d98abaa128ff2ee48520313", null ],
    [ "set", "classColor.html#a07a6c69ebd64a781d465e88807d7677c", null ],
    [ "b", "classColor.html#a7c20352fa7e6e83472155c7a060b7263", null ],
    [ "r", "classColor.html#a315e2fdcc308f31e9551907b362caf32", null ],
    [ "v", "classColor.html#a4442d21cdde971a1f7b45318e65b34df", null ]
];